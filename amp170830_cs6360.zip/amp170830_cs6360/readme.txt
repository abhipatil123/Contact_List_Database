The folder 'Project1' contains all the files related to the application. Copy the folder in the directory of your choice.

Languages : Javascript
Database : Mysql (Version: 8.0.12)
Server Side : PHP(Version: 7.0)
Front-end : HTML5, JS (v2.6.1), CSS 3, Bootstrap v4.1.3, JQuery v3.3.1

Server Setup:

Download MAMP app and start the Apache and MySQL servers at port 80 and 3306 respectively
Put all the server side files in htdocs folders in MAMP
Type localhost in your web browser to check if server is connected

Starting point of the application - home.html

Launch Application :
Now open the home.html file in your web browser. Use the quick start guide to use the application.